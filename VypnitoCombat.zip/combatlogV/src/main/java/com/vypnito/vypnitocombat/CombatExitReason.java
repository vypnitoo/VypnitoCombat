package com.vypnito.vypnitocombat;

public enum CombatExitReason {
	NATURAL_TIMEOUT,
	DISCONNECT,
	DEATH,
	MANUAL
}